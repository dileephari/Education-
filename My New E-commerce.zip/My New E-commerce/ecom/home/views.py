from django.shortcuts import render, redirect, get_object_or_404
from . models import *
from .models import Product, Catagory
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from home.form import CustomUserForm
from django.contrib import messages
from flask import Flask
from django.http import JsonResponse
from .models import Names
from .models import Navimages

# Create your views here.

def index(request):
    # Filter trending products
    trending_products = Product.objects.filter(trending=True)

    # Get distinct categories from the trending products
    catagories = trending_products.values_list('catagory', flat=True).distinct()

    # Create a dictionary to hold products and sub-heading by category
    products_by_catagory = {}
    for catagory in catagories:
        # Get a representative product to fetch the sub-heading
        representative_product = trending_products.filter(catagory=catagory).first()
        sub_heading = representative_product.sub_heading if representative_product else ''

        # Collect products and sub-heading for this category
        products_by_catagory[catagory] = {
            'sub_heading': sub_heading,
            'products': trending_products.filter(catagory=catagory)
        }

    context = {
        'products_by_catagory': products_by_catagory,
    }
    return render(request, 'index.html', context)

def collections(request):
    catagories = Catagory.objects.all()  # Filter using 'status'
    return render(request, "collections.html", {"catagories": catagories})

def catagory_detail(request, catagory_id):
    catagory = get_object_or_404(Catagory, pk=catagory_id)
    products = Product.objects.filter(catagory=catagory)
    return render(request, "catagory_detail.html", {"catagory": catagory, "products": products})
 

def catagory_list(request):
    catagories = Catagory.objects.all()
    context = {
        'catagories': catagories
    }
    return render(request, 'catagory_list.html', context)


def product_detail(request, product_id):
    # Fetch the product details by its ID
    product = get_object_or_404(Product, id=product_id)

    context = {
        'product': product
    }
    return render(request, 'product_detail.html', context)    

def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    
    # Assuming you have a form handling quantity input
    quantity = request.POST.get('quantity', 1)
    
    # Ensure request.user is a User instance
    if not isinstance(request.user, User):
        # Handle cases where request.user is not authenticated properly
        # You can redirect to login or handle this scenario as per your application's logic
        return redirect('login')  # Example redirect to login page
    
    try:
        # Try to get the existing cart item for this product and user
        cart_item = CartItem.objects.get(user=request.user, product=product)
        
        # If cart item exists, update quantity and save
        cart_item.quantity += int(quantity)
        cart_item.save()
        
    except CartItem.DoesNotExist:
        # If cart item does not exist, create a new one
        cart_item = CartItem.objects.create(
            user=request.user,
            product=product,
            quantity=quantity,
            price=product.price
        )
    
    return redirect('cart')

def cart_view(request):
    # Fetch cart items for the current authenticated user
    if request.user.is_authenticated:
        cart_items = CartItem.objects.filter(user=request.user)
    else:
        cart_items = []  # Empty list if user is not authenticated
    
    return render(request, 'cart.html', {'cart_items': cart_items})

def remove_from_cart(request, cart_item_id):
    cart_item = get_object_or_404(CartItem, pk=cart_item_id)
    cart_item.delete()
    return redirect('cart') 

def register(request):
    form=CustomUserForm()
    if request.method=='POST':
        form=CustomUserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Registarion Success You can Login Now..!")
            return redirect('/login')
    return render(request,"register.html",{'form':form})


def logout_view(request):
  if request.user.is_authenticated:
    logout(request)
    messages.success(request,"Loged out Successfully")
  return redirect("/")

def login_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, 'Login successful!')
            return redirect('home')  # Replace 'home' with your desired redirect URL
        else:
            messages.error(request, 'Incorrect username or password.')
    
    return render(request, 'login.html')        


def search_view(request):
    query = request.GET.get('q')
    products = []
    categories = []

    if query:
        # Search for products
        products = Product.objects.filter(name__icontains=query)

        # Search for categories (optional, based on your requirements)
        catagories = Catagory.objects.filter(name__icontains=query)

    return render(request, 'search.html', {
        'query': query,
        'products': products,
        'catagories': catagories,
    })

    return render(request, 'search.html', context)



def get_names(request):
    search = request.GET.get('search')
    payload = []
    
    if search:
        objs = Names.objects.filter(name__startswith=search)  # Corrected filter syntax

        for obj in objs:
            payload.append({
                'name': obj.name
            })
    
    return JsonResponse({
        'status': True,
        'payload': payload
    })           

def shop_view(request):
    # Get the selected category from the query parameters
    selected_catagory = request.GET.get('catagory')

    # Filter products that are trending
    trending_products = Product.objects.filter(trending=True)

    # Define categories you want to include
    catagories = ['Mobiles', 'Gadgets', 'Personal Care']

    # Create a dictionary to hold products and sub-heading by category
    products_by_catagory = {}
    for catagory in catagories:
        if selected_catagory and selected_catagory == catagory:
            # Collect products and sub-heading for the selected category
            representative_product = trending_products.filter(catagory=catagory).first()
            sub_heading = representative_product.sub_heading if representative_product else catagory
            products_by_catagory[catagory] = {
                'sub_heading': sub_heading,
                'products': trending_products.filter(catagory=catagory)
            }
        elif not selected_catagory:
            # Display all categories if no specific category is selected
            representative_product = trending_products.filter(catagory=catagory).first()
            sub_heading = representative_product.sub_heading if representative_product else catagory
            products_by_catagory[catagory] = {
                'sub_heading': sub_heading,
                'products': trending_products.filter(catagory=catagory)
            }
        else:
            # Optionally, you can handle cases for when a category does not match
            products_by_catagory[catagory] = {
                'sub_heading': catagory,
                'products': []
            }

    context = {
        'products_by_catagory': products_by_catagory,
    }
    return render(request, 'shop.html', context)

def nav_view(request):
    # Retrieve all Navimages objects
    nav_images = Navimages.objects.all()
    
    # Pass the data to the template
    return render(request, 'nav.html', {'nav_images': nav_images})    