from django.contrib import admin
from django.urls import path, include
from .import views
from .views import logout_view
from .views import nav_view

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name="home"),
    path('collections/', views.collections,name='collections'),
    path('collections/<int:catagory_id>/', views.catagory_detail, name='catagory_detail'),
    path('catagory_detail/', views.catagory_detail, name='catagory_detail'),
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('cart/', views.cart_view, name='cart'),
    path('add_to_cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('remove-from-cart/<int:cart_item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('register/', views.register,name='register'),
    path('login', views.login_user, name='login'),
    path('logout/', logout_view, name='logout'),
    path('search/', views.search_view, name='search'),
    path('shop/', views.shop_view, name='shop'),
    path('nav/', nav_view, name='nav'),
    
    
]
